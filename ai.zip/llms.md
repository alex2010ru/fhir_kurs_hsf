# fhir.education.kursig#0.1.0: Min FHIR-utbildning - Sushi+IG

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [My first profile with fsh](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Min FHIR-utbildning - Sushi+IG](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
